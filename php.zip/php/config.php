<?php 
 
 $con = mysqli_connect("localhost","root","","db_login") or die("Couldn't connect");

?>